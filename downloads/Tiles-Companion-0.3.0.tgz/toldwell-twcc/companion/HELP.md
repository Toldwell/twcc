# Tiles — Companion Module

Controls cinema cameras via the **Tiles** iPad app Control API (WebSocket, API 1).

## Setup

1. Open Tiles on iPad → **Settings → Control API** → enable it and copy the pairing token.
2. In Companion, add a connection, choose **Tiles**, and enter:
   - **Host**: the iPad's LAN IP (e.g. `192.168.1.50`)
   - **Port**: `51800` (default)
   - **Token**: the pairing token from the app

## Important: cameras and pages are addressed by ID

Buttons store the camera's UUID, not its label. The dropdown shows `C · FX3` but what's saved is the UUID. If you rename a camera in the app, existing buttons keep driving the same camera — nothing breaks silently. Variable names (`$(twcc:C_iso)`) do update to the new label after the next snapshot.

## Actions

| Action | Notes |
|---|---|
| REC — Start/Stop | `set record=recording/idle` |
| REC — Toggle | Server resolves from confirmed state; `unknown` → `rejected` (logged, not retried) |
| Field — Set Value | Absolute set; value must be in options or within range |
| Field — Step +/− | Steps through options (choice) or by N×step units (level) |
| Field — Cycle | Next option, wrapping |
| Field — Toggle Bool | false colour, LUT on/off, colour bars, flip |
| App — Show Page | Switches the iPad's current page (by page ID) |
| App — Set Page Linking | On / Off / Toggle — resolves from current pages state |
| App — Set Link Group | Enable/disable a link group (whiteBalance, frameRate, shutter, record) |

Every camera action has a camera dropdown showing `Label · Model`.

## Feedbacks

| Feedback | Condition |
|---|---|
| **Recording** | `connection=connected` AND `record.value=recording` — never optimistic |
| **REC Unknown** | `record.value=unknown` (camera offline or transitioning) |
| **REC Request Pending** | `record.request` is set |
| **Camera Connected** | `connection=connected` |
| **Camera Not Connected** | `connection≠connected` |
| **Field Equals Value** | Confirmed field value matches string |
| **Field Writable** | Field present and `writable=true` |
| **Radio Bars Below** | `radio.bars < threshold` |

## Variables

Variables use the camera's current label as prefix (e.g. `C` for camera labelled "C"):

| Variable | Meaning |
|---|---|
| `$(twcc:C_rec_state)` | `idle` / `recording` / `unknown` |
| `$(twcc:C_rec_time)` | `HH:MM:SS` elapsed, ticked locally once/sec |
| `$(twcc:C_iso)` | ISO, and so on for all 25 fields |
| `$(twcc:C_battery)` | Battery % |
| `$(twcc:C_media_minutes)` | Media minutes remaining |
| `$(twcc:C_latency)` | Latency ms |
| `$(twcc:C_model)` | Model string |
| `$(twcc:C_connection)` | Connection state |
| `$(twcc:C_id)` | Camera UUID |
| `$(twcc:current_page)` | Current page name |
| `$(twcc:radio_bars)` | HaLow bars 0.0–1.0 |
| `$(twcc:halow_signal_dbm)` | HaLow first-node dBm |

**On rename:** variable IDs update to the new label at the next snapshot. Button text referencing the old label will go blank until Companion refreshes its variable subscriptions. The camera action/feedback options (stored as UUIDs) are unaffected.
